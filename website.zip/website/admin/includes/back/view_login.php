<div class="d-sm-flex align-items-center justify-content-between mb-4">
<h1 class="h3 mb-0 text-gray-800">Logins</h1>
<a href="index" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-arrow-left fa-sm text-white-50"></i> Go Back</a>
</div>
<div class="main-card mb-4 card shadow">
    <div class="card-body form-add">
        <div class="card-title">
            <h5 class="text-gray-800 text-center text-uppercase">
                <?php 
                if(isset($_GET['admin'])) {
                    echo "ADMINS";
                } 
                else if (isset($_GET['staff'])) {
                    echo "STAFF";
                }
                else if (isset($_GET['cust'])) {
                    echo "CUSTOMERS";
                }
                else {
                    echo "ALL"; ?>
                    <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr data-toggle="tooltip" data-placement="top" data-original-title="Click on the column names to sort accordingly.">
                    <th>Email</th>
                    <th>Date Added</th>
                    <th>Date Modified</th>
                    <th></th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                    <th>Email</th>
                    <th>Date Added</th>
                    <th>Date Modified</th>
                    <th></th>
                </tr>
              </tfoot>
              <tbody>
                <?php $admin->display_customers(); ?>
              </tbody>
            </table>
        </div>

                <?php }
                ?>
            </h5>
        </div>      
            <div class="border-top-primary border-table-top"></div>
            <?php 
            $admin->delete_logins();
            ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr data-toggle="tooltip" data-placement="top" data-original-title="Click on the column names to sort accordingly.">
                    <th>ID</th>
                    <th>Student ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Date Added</th>
                    <th>Date Modified</th>
                    <th></th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                    <th>ID</th>
                    <th>Student ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Date Added</th>
                    <th>Date Modified</th>
                    <th></th>
                </tr>
              </tfoot>
              <tbody>
                <?php $admin->display_customers(); ?>
              </tbody>
            </table>
        </div>
        <div class="border-bottom-primary border-table-bottom"></div>             
    </div>
</div>